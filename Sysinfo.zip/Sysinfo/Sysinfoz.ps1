﻿Add-type -assemblyname system.drawing
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName PresentationFramework
[System.Windows.Forms.Application]::EnableVisualStyles()

$driveletter = $pwd.drive.name
$root = "$driveletter" + ":"

start ".\splashscreen.exe"

set-location "$root\\_TECH\\Applications\Diagnostique\Source\Sysinfo" #met la location au repertoir actuel
$loc = Get-Location #assgine la location du repertoir actuel

$logfilepath=".\Log.txt"
#$objetlog = [Log]::new($logfilepath)

function AddLog ($message)
{
$message + "`r`n" | Out-file -filepath $logfilepath -append -force
}

$sync = [Hashtable]::Synchronized(@{}) # for talking across runspaces

$Form = New-Object System.Windows.Forms.Form
$Form.ClientSize = '500,500'
$Form.Text = "Sysinfo"
#$Form.BackgroundImage = $img
#$Form.MaximizeBox = $false
#$Form.MinimizeBox = $false
$Form.icon = New-Object system.drawing.icon (".\Icone.ico") 
#$Form.KeyPreview = $True
$Form.TopMost = $true$Form.StartPosition = "CenterScreen"

$title1 = New-Object System.Windows.Forms.Label
$title1.Location = New-Object System.Drawing.Point(0,10)
$title1.AutoSize = $false
$title1.width = 65
$title1.height = 18
$title1.Font= 'Arial Black,9'
$title1.ForeColor='white'
$title1.BackColor = 'darkred'
$title1.Text = "Sys"
$title1.TextAlign = 'MiddleCenter'
$Form.Controls.Add($title1)

$title2 = New-Object System.Windows.Forms.Label
$title2.Location = New-Object System.Drawing.Point(0,210)
$title2.AutoSize = $false
$title2.width = 65
$title2.height = 18
$title2.Font= 'Arial Black,9'
$title2.ForeColor='white'
$title2.BackColor = 'darkgreen'
$title2.Text = "HDD"
$title2.TextAlign = 'MiddleCenter'
$Form.Controls.Add($title2)

$title3 = New-Object System.Windows.Forms.Label
$title3.Location = New-Object System.Drawing.Point(215,10)
$title3.AutoSize = $false
$title3.width = 65
$title3.height = 18
$title3.Font= 'Arial Black,9'
$title3.ForeColor='white'
$title3.BackColor = 'red'
$title3.Text = "CPU"
$title3.TextAlign = 'MiddleCenter'
$Form.Controls.Add($title3)

$title4 = New-Object System.Windows.Forms.Label
$title4.Location = New-Object System.Drawing.Point(0,130)
$title4.AutoSize = $false
$title4.width = 65
$title4.height = 18
$title4.Font= 'Arial Black,9'
$title4.ForeColor='white'
$title4.BackColor = 'blue'
$title4.Text = "Mobo"
$title4.TextAlign = 'MiddleCenter'
$Form.Controls.Add($title4)

$title5 = New-Object System.Windows.Forms.Label
$title5.Location = New-Object System.Drawing.Point(215,110)
$title5.AutoSize = $false
$title5.width = 65
$title5.height = 18
$title5.Font= 'Arial Black,9'
$title5.ForeColor='white'
$title5.BackColor = 'darkblue'
$title5.Text = "Memory"
$title5.TextAlign = 'MiddleCenter'
$Form.Controls.Add($title5)

$title6 = New-Object System.Windows.Forms.Label
$title6.Location = New-Object System.Drawing.Point(215,250)
$title6.AutoSize = $false
$title6.width = 65
$title6.height = 18
$title6.Font= 'Arial Black,9'
$title6.ForeColor='white'
$title6.BackColor = 'darkmagenta'
$title6.Text = "GPU"
$title6.TextAlign = 'MiddleCenter'
$Form.Controls.Add($title6)

$title7 = New-Object System.Windows.Forms.Label
$title7.Location = New-Object System.Drawing.Point(215,310)
$title7.AutoSize = $false
$title7.width = 65
$title7.height = 18
$title7.Font= 'Arial Black,9'
$title7.ForeColor='white'
$title7.BackColor = 'magenta'
$title7.Text = "Batt"
$title7.TextAlign = 'MiddleCenter'
$Form.Controls.Add($title7)

#afficherlog
$afficherlog = New-Object System.Windows.Forms.Button
$afficherlog.Location = New-Object System.Drawing.Point(370,470)
$afficherlog.Width = '100'
$afficherlog.Height = '30'
$afficherlog.ForeColor='black'
$afficherlog.BackColor = 'darkgreen'
$afficherlog.Text = "Ouvrir Log"
$afficherlog.Font= 'Microsoft Sans Serif,10'
$afficherlog.FlatStyle = 'Flat'
$afficherlog.FlatAppearance.BorderSize = 2
$afficherlog.FlatAppearance.BorderColor = 'black'
$afficherlog.FlatAppearance.MouseDownBackColor = 'Darkmagenta'
$afficherlog.FlatAppearance.MouseOverBackColor = 'gray'
$afficherlog.Add_MouseEnter({$afficherlog.ForeColor = 'White'})
$afficherlog.Add_MouseLeave({$afficherlog.ForeColor = 'black'})
$afficherlog.Add_Click({
start $logfilepath
})
$afficherlog.visible = $false
$Form.Controls.Add($afficherlog)

#exportlog
$exportlog = New-Object System.Windows.Forms.Button
$exportlog.Location = New-Object System.Drawing.Point(370,470)
$exportlog.Width = '100'
$exportlog.Height = '30'
$exportlog.ForeColor='black'
$exportlog.BackColor = 'darkred'
$exportlog.Text = "Exporter Log"
$exportlog.Font= 'Microsoft Sans Serif,10'
$exportlog.FlatStyle = 'Flat'
$exportlog.FlatAppearance.BorderSize = 2
$exportlog.FlatAppearance.BorderColor = 'black'
$exportlog.FlatAppearance.MouseDownBackColor = 'Darkmagenta'
$exportlog.FlatAppearance.MouseOverBackColor = 'gray'
$exportlog.Add_MouseEnter({$exportlog.ForeColor = 'White'})
$exportlog.Add_MouseLeave({$exportlog.ForeColor = 'black'})
$exportlog.Add_Click({
Clear-Content $logfilepath
addlog (Get-Date).ToString()
addlog "Ordi:`r`n Modèle: $getmodel Fabriquant : $getmanufacturer OS: $getOS"
addlog "Bios:`r`n Nom: $getBIOSName Version: $getBIOSversion"
addlog "CPU:`r`n Nom : $getCPUname`r`n Socket: $getCPUSocket Vitesse: $getcpumaxspeed mhz Utilisation: $getcpuload %"
addlog ("Disque:`r`n" + (disk))
addlog ((diskmarkinfoLog))
addlog "Ram:`r`n Capacité: $getRamtotalspaceGB GB ($percentagefreespaceram libre)"
addlog ((ram))
addlog "GPU:`r`n Modèle: $getGPU Pilote(date) : $GPUdriverdate"
addlog "Mobo:`r`n Fabriquant: $getmoboManufacturer Modèle: $getmoboProduct Serial: $getmoboSerial"
addlog ("Batterie:`r`n" + (Batteryexist))
$afficherlog.visible = $true
$exportlog.Visible - $false
})
$Form.Controls.Add($exportlog)


#BIOS 
$getBIOSName = Get-CimInstance -ClassName Win32_BIOS | Select-object -Expand Name | Out-string
$getBIOSVersion = Get-CimInstance -ClassName Win32_BIOS | Select-object -Expand Version | Out-string

                                                    
$titlebiosname = New-Object System.Windows.Forms.Label
$titlebiosname.Location = New-Object System.Drawing.Point(0,070)
$titlebiosname.AutoSize = $false
$titlebiosname.width = 65
$titlebiosname.height = 15
$titlebiosname.Font= 'Arial Black,8'
$titlebiosname.ForeColor='black'
$titlebiosname.BackColor = 'darkcyan'
$titlebiosname.Text = "Nom Bios"
$titlebiosname.TextAlign = 'Middleleft'
$Form.Controls.Add($titlebiosname)

$BIOSname = New-Object System.Windows.Forms.label
$BIOSname.Location = New-Object System.Drawing.Point(65,070)
$BIOSname.width = 150
$BIOSname.height = 15
$BIOSname.Text = $getBIOSName
$BIOSname.Font= 'Microsoft Sans Serif,8'
$BIOSname.TextAlign = 'BottomLeft'
$Form.Controls.Add($BIOSname)

$titlebiosversion = New-Object System.Windows.Forms.Label
$titlebiosversion.Location = New-Object System.Drawing.Point(0,090)
$titlebiosversion.AutoSize = $false
$titlebiosversion.width = 65
$titlebiosversion.height = 15
$titlebiosversion.Font= 'Arial Black,8'
$titlebiosversion.ForeColor='black'
$titlebiosversion.BackColor = 'darkcyan'
$titlebiosversion.Text = "Bios vers."
$titlebiosversion.TextAlign = 'Middleleft'
$Form.Controls.Add($titlebiosversion)

$BIOSversion = New-Object System.Windows.Forms.label
$BIOSversion.Location = New-Object System.Drawing.Point(65,090)
$BIOSversion.width = 150
$BIOSversion.height = 15
$BIOSversion.Text = $getBIOSVersion
$BIOSversion.Font= 'Microsoft Sans Serif,8'
$BIOSversion.TextAlign = 'Middleleft'
$Form.Controls.Add($BIOSversion)

#marque, modele et OS
$getmodel= Get-CimInstance -ClassName Win32_ComputerSystem  | Select-Object -Property @{Name = 'Model'; Expression = {$_.Model -replace "To Be Filled By O.E.M.","N/A"}} | select-object -expand Model
$getmanufacturer = Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -Property @{Name = 'Manufacturer'; Expression = {$_.Manufacturer -replace "To Be Filled By O.E.M.","N/A"}} | select-object -expand Manufacturer
$getOS = Get-CimInstance -ClassName CIM_OperatingSystem | Select-Object -Property @{Name = 'OS'; Expression = {$_.Caption -replace "Microsoft ",""}} | select-object -expand OS

$titlemarque = New-Object System.Windows.Forms.Label
$titlemarque.Location = New-Object System.Drawing.Point(0,030)
$titlemarque.AutoSize = $false
$titlemarque.width = 65
$titlemarque.height = 15
$titlemarque.Font= 'Arial Black,8'
$titlemarque.ForeColor='black'
$titlemarque.BackColor = 'darkcyan'
$titlemarque.Text = "Marque"
$titlemarque.TextAlign = 'Middleleft'
$Form.Controls.Add($titlemarque)

$marque = New-Object System.Windows.Forms.label
$marque.Location = New-Object System.Drawing.Point(65,030)
$marque.width = 150
$marque.height = 15
$marque.Text = "$getmanufacturer"
$marque.Font= 'Microsoft Sans Serif,8'
$marque.TextAlign = 'MiddleLeft'
$marque.AutoSize = $false
$Form.Controls.Add($marque)

$titlemodel = New-Object System.Windows.Forms.Label
$titlemodel.Location = New-Object System.Drawing.Point(0,050)
$titlemodel.AutoSize = $false
$titlemodel.width = 65
$titlemodel.height = 15
$titlemodel.Font= 'Arial Black,8'
$titlemodel.ForeColor='black'
$titlemodel.BackColor = 'darkcyan'
$titlemodel.Text = "Modèle"
$titlemodel.TextAlign = 'Middleleft'
$Form.Controls.Add($titlemodel)

$model = New-Object System.Windows.Forms.label
$model.Location = New-Object System.Drawing.Point(65,050)
$model.width = 150
$model.height = 15
$model.Text = "$getmodel"
$model.Font= 'Microsoft Sans Serif,8'
$model.ForeColor='darkblue'
$model.TextAlign = 'Middleleft'
$model.AutoSize = $false
$Form.Controls.Add($model)


$titleOS = New-Object System.Windows.Forms.Label
$titleOS.Location = New-Object System.Drawing.Point(0,110)
$titleOS.AutoSize = $false
$titleOS.width = 65
$titleOS.height = 15
$titleOS.Font= 'Arial Black,8'
$titleOS.ForeColor='black'
$titleOS.BackColor = 'darkcyan'
$titleOS.Text = "OS"
$titleOS.TextAlign = 'Middleleft'
$Form.Controls.Add($titleOS)

$OS = New-Object System.Windows.Forms.label
$OS.Location = New-Object System.Drawing.Point(65,110)
$OS.width = 150
$OS.height = 15
$OS.Text = "$getOS"
$OS.Font= 'Microsoft Sans Serif,8'
$OS.TextAlign = 'MiddleLeft'
$OS.AutoSize = $false
$Form.Controls.Add($OS)

#CPU
$getCPUName = Get-CimInstance -ClassName Win32_Processor | Select-object -Expand Name

$titleCPUname = New-Object System.Windows.Forms.Label
$titleCPUname.Location = New-Object System.Drawing.Point(215,030)
$titleCPUname.AutoSize = $false
$titleCPUname.width = 65
$titleCPUname.height = 15
$titleCPUname.Font= 'Arial Black,8'
$titleCPUname.ForeColor='black'
$titleCPUname.BackColor = 'darkcyan'
$titleCPUname.Text = "Modèle"
$titleCPUname.TextAlign = 'Middleleft'
$Form.Controls.Add($titleCPUname)

$CPUname = New-Object System.Windows.Forms.label
$CPUname.Location = New-Object System.Drawing.Point(280,030)
$CPUname.width = 175
$CPUname.height = 15
$CPUname.Text = $getCPUName
$CPUname.Font= 'Microsoft Sans Serif,8'
$CPUname.ForeColor='darkblue'
$CPUname.TextAlign = 'MiddleLeft'
$Form.Controls.Add($CPUname)


$getCPUSocket = Get-CimInstance -ClassName Win32_Processor | Select-object -Expand SocketDesignation

$titleCPUSocket = New-Object System.Windows.Forms.Label
$titleCPUSocket.Location = New-Object System.Drawing.Point(215,050)
$titleCPUSocket.AutoSize = $false
$titleCPUSocket.width = 65
$titleCPUSocket.height = 15
$titleCPUSocket.Font= 'Arial Black,8'
$titleCPUSocket.ForeColor='black'
$titleCPUSocket.BackColor = 'darkcyan'
$titleCPUSocket.Text = "Socket"
$titleCPUSocket.TextAlign = 'Middleleft'
$Form.Controls.Add($titleCPUSocket)

$CPUSocket = New-Object System.Windows.Forms.label
$CPUSocket.Location = New-Object System.Drawing.Point(280,050)
$CPUSocket.width = 150
$CPUSocket.height = 15
$CPUSocket.Text = $getCPUSocket
$CPUSocket.Font= 'Microsoft Sans Serif,8'
$CPUSocket.TextAlign = 'MiddleLeft'
$Form.Controls.Add($CPUSocket)

$getCPUMaxspeed = Get-CimInstance -ClassName Win32_Processor | Select-object -Expand MaxClockSpeed

$titleCPUMaxspeed = New-Object System.Windows.Forms.Label
$titleCPUMaxspeed.Location = New-Object System.Drawing.Point(215,070)
$titleCPUMaxspeed.AutoSize = $false
$titleCPUMaxspeed.width = 65
$titleCPUMaxspeed.height = 15
$titleCPUMaxspeed.Font= 'Arial Black,8'
$titleCPUMaxspeed.ForeColor='black'
$titleCPUMaxspeed.BackColor = 'darkcyan'
$titleCPUMaxspeed.Text = "Vitesse"
$titleCPUMaxspeed.TextAlign = 'Middleleft'
$Form.Controls.Add($titleCPUMaxspeed)

$CPUMaxspeed = New-Object System.Windows.Forms.label
$CPUMaxspeed.Location = New-Object System.Drawing.Point(280,070)
$CPUMaxspeed.width = 150
$CPUMaxspeed.height = 15
$CPUMaxspeed.Text = "$getCPUMaxspeed Mhz"
$CPUMaxspeed.Font= 'Microsoft Sans Serif,8'
$CPUMaxspeed.TextAlign = 'MiddleLeft'
$Form.Controls.Add($CPUMaxspeed)

$SBGetCPULoad = {

	$flag = $true
	
    while($flag)
    {                
        function GetCPUload($CPULoad) {
            $getCPULoad = Get-CimInstance -ClassName Win32_Processor | Select-object -Expand LoadPercentage
            $sync.CPULoad.Text = "$getCPULoad %"
            if ($getCPULoad -ge 90) {
                $sync.CPULoad.ForeColor = 'Darkcyan'
            }
        }
		
		GetCPUload
        sleep -Milliseconds 750 # pause la boucle 3 quart de seconde
    }
}


function Start-Runspace
{
    param ($SBGetCPULoad)
    $runspaceCPULoad = [runspacefactory]::CreateRunspace()
    $runspaceCPULoad.ApartmentState = "STA" #https://docs.microsoft.com/en-us/dotnet/api/system.threading.apartmentstate?view=net-5.0
    $runspaceCPULoad.ThreadOptions = "ReuseThread" #https://docs.microsoft.com/en-us/dotnet/api/system.management.automation.runspaces.psthreadoptions?view=powershellsdk-7.0.0
    $runspaceCPULoad.Name = "Thread_GestErreurs" #le nom
    $runspaceCPULoad.Open() #doit etre open avant d'être utilisé
    $runspaceCPULoad.SessionStateProxy.SetVariable("sync", $sync) #passe les variable qui vont être utilisé
    $psCmdload = [PowerShell]::Create().AddScript($SBGetCPULoad)
    $psCmdload.Runspace = $runspaceCPULoad
    $AsyncObjectload = $psCmdload.BeginInvoke()
    Start-Sleep -Milliseconds 250
    #$runspaceCPULoad.Dispose()
}

Start-Runspace $SBGetCPULoad

$titleCPULoad = New-Object System.Windows.Forms.Label
$titleCPULoad.Location = New-Object System.Drawing.Point(215,090)
$titleCPULoad.AutoSize = $false
$titleCPULoad.width = 65
$titleCPULoad.height = 15
$titleCPULoad.Font= 'Arial Black,8'
$titleCPULoad.ForeColor='black'
$titleCPULoad.BackColor = 'darkcyan'
$titleCPULoad.Text = "Load"
$titleCPULoad.TextAlign = 'Middleleft'
$Form.Controls.Add($titleCPULoad)

$CPULoad = New-Object System.Windows.Forms.label
$CPULoad.Location = New-Object System.Drawing.Point(280,090)
$CPULoad.width = 150
$CPULoad.height = 15
#$CPULoad.Text = "$getCPULoad %"
$CPULoad.Font= 'Microsoft Sans Serif,8'
$CPULoad.TextAlign = 'topLeft'
$CPULoad.AutoSize = $false
$Form.Controls.Add($CPULoad)

#disk
<#
function hdsslog
{
$PathHDSentinelData = Get-Content "$root\\_TECH\\Applications\\Diagnostique\\Source\\HDD\\HD_Sentinnel\\HDSData\\HDSentinel_5.70 PRO_report.txt"
$lignedisk = "" #initialise la variable vide


foreach ($ligne in $PathHDSentinelData) #pour chaque ligne dans le fichier, car chaque ligne est un objet
{
    if($ligne -match "Drive \d+") #si une ligne match drive + un chiffre
    {
        $lignedisk = $ligne
    }

    elseif($lignedisk -and $ligne -match "Interface used") 
    {       
        if ($ligne -notmatch 'USB')
        {
        "$lignedisk `r`n $ligne`r`n" -replace "  . . . ", "" -replace "Used", "" -replace " Gen3, 6 GBps"     
        }
    }

    elseif($lignedisk -and $ligne -match "Disk Fitness") 
    {
        if($ligne -notmatch '-1 %')
        {
        "$ligne $ligneInterfaceused`r`n"  -replace "  . . . .", ""
        }
        $lignedisk = "" #flusher une fois la variable a la fin
    }
}
}
#>

function diskmarkinfoLog
{
$logfile = "$root\\_Tech\\Applications\\Diagnostique\\Source\HDD\CrystalDiskInfoPortable\App\CrystalDiskInfo\diskinfo.txt"
$contentlogfile = Get-Content $logfile
$lignedisk = "" #initialise la variable vide

    foreach ($ligne in $contentlogfile) #pour chaque ligne dans le fichier, car chaque ligne est un objet
    {
        if($ligne -match "Model") 
        {
            $lignedisk = $ligne
        }

        elseif($lignedisk -and $ligne -match "Interface") 
        {       
            "$lignedisk `r`n $ligne`r`n"   
        }

        elseif($lignedisk -and $ligne -match " Health Status") 
        {
            "$ligne `r`n $ligneInterfaceused`r`n"
            $lignedisk = "" #flusher une fois la variable a la fin
        }
    }
}

function hdss
{
start -wait  "$root\\_Tech\\Applications\\Diagnostique\\Source\HDD\CrystalDiskInfoPortable\CrystalDiskInfoPortable.exe"  -ArgumentList "/copyexit"
diskmarkinfoLog
Stop-Process -name splashscreen -Force
}

#disk
function disk
{
$getHDDID1 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType = '3'" | Select-Object -Expand DeviceID -First 1
$getHDDID2 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType = '3'" | Select-Object -Expand DeviceID -skip 1 -First 1
$getHDDID3 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType = '3'" | Select-Object -Expand DeviceID -skip 2 -First 1
$getHDDID4 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType = '3'" | Select-Object -Expand DeviceID -skip 3 -First 1
$getHDDID5 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType = '3'" | Select-Object -Expand DeviceID -skip 4 -First 1

    if($getHDDID1)
    {
        $getHDDSize1 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID like '$getHDDID1'" | Select-Object -Expand size
            if ($getHDDSize1 -ge 1gb)
            {
                $gethddsizeGB1 = [int]($getHDDSize1 /1gb)
                $getHDDFreespace  = Get-CimInstance -ClassName Win32_LogicalDisk  -Filter "DeviceID like '$getHDDID1'" | Select-Object -Expand FreeSpace
                $gethddfreespaceGB1 = [int]($getHDDFreespace / 1gb)
                $percentagefreespace1 = ($gethddfreespaceGB1 / $gethddsizeGB1).tostring("P") # % espace disponible
                "$getHDDID1 $gethddsizeGB1 GB $percentagefreespace1 libre"
            }
    }

    if($getHDDID2)
    {
        $getHDDSize2 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID like '$getHDDID2'" | Select-Object -Expand size
            if ($getHDDSize2 -ge 1gb)
            {
                $gethddsizeGB2 = [int]($getHDDSize2 /1gb)
                $getHDDFreespace  = Get-CimInstance -ClassName Win32_LogicalDisk  -Filter "DeviceID like '$getHDDID2'" | Select-Object -Expand FreeSpace
                $gethddfreespaceGB2 = [int]($getHDDFreespace / 1gb)
                $percentagefreespace2 = ($gethddfreespaceGB2 / $gethddsizeGB2).tostring("P") # % espace disponible
                "$getHDDID2 $gethddsizeGB2 GB $percentagefreespace2 libre"
            }
    }

    if($getHDDID3)
    {
        $getHDDSize3 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID like '$getHDDID3'" | Select-Object -Expand size
            if($getHDDSize3 -ge 1gb)
            {
                $gethddsizeGB3 = [int]($getHDDSize3 /1gb)
                $getHDDFreespace  = Get-CimInstance -ClassName Win32_LogicalDisk  -Filter "DeviceID like '$getHDDID3'" | Select-Object -Expand FreeSpace
                $gethddfreespaceGB3 = [int]($getHDDFreespace / 1gb)
                $percentagefreespace3 = ($gethddfreespaceGB3 / $gethddsizeGB3).tostring("P") # % espace disponible
                "$getHDDID3 $gethddsizeGB3 GB $percentagefreespace3 libre"
            }
    }

    if($getHDDID4)
    {
        $getHDDSize4 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID like '$getHDDID4'" | Select-Object -Expand size
            if($getHDDSize4 -ge 1gb)
            {
                $gethddsizeGB4 = [int]($getHDDSize4 /1gb)
                $getHDDFreespace  = Get-CimInstance -ClassName Win32_LogicalDisk  -Filter "DeviceID like '$getHDDID4'" | Select-Object -Expand FreeSpace
                $gethddfreespaceGB4 = [int]($getHDDFreespace / 1gb)
                $percentagefreespace4 = ($gethddfreespaceGB4 / $gethddsizeGB4).tostring("P") # % espace disponible
                "$getHDDID4 $gethddsizeGB4 GB $percentagefreespace4 libre"
            }
    }

    if($getHDDID5)
    {
        $getHDDSize5 = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID like '$getHDDID5'" | Select-Object -Expand size
            if($getHDDSize4 -ge 1gb)
            {
                $gethddsizeGB5 = [int]($getHDDSize5 /1gb)
                $getHDDFreespace  = Get-CimInstance -ClassName Win32_LogicalDisk  -Filter "DeviceID like '$getHDDID5'" | Select-Object -Expand FreeSpace
                $gethddfreespaceGB5 = [int]($getHDDFreespace / 1gb)
                $percentagefreespace5 = ($gethddfreespaceGB5 / $gethddsizeGB3).tostring("P") # % espace disponible
                "$getHDDID5 $gethddsizeGB5 GB $percentagefreespace5 libre"
            }
    }
}

<#    
function smart
{
$smart =  Get-WmiObject -namespace root\wmi –class MSStorageDriver_FailurePredictStatus -ErrorAction SilentlyContinue
if ($smart)
{
    status
}
else
{
    "N/A"
}
}

function status
{
    foreach($disk in disk)
    {
        $status = Get-WmiObject -namespace root\wmi –class MSStorageDriver_FailurePredictStatus | select-object -expand Predictfailure
            if ($status -match "True")
            {
                $wearerreur = Get-WmiObject -namespace root\wmi –class MSStorageDriver_FailurePredictStatus | select-object -expand reason -first 1
                "Erreur code: $wearerreur"
            }
            elseif ($status -match "False")
            {
                hdss
            }
    }
}
#>

$titleHDD = New-Object System.Windows.Forms.Label
$titleHDD.Location = New-Object System.Drawing.Point(0,230)
$titleHDD.AutoSize = $false
$titleHDD.width = 65
$titleHDD.height = 15
$titleHDD.Font= 'Arial Black,8'
$titleHDD.ForeColor='black'
$titleHDD.BackColor = 'darkcyan'
$titleHDD.Text = "Disques"
$titleHDD.TextAlign = 'Middleleft'
$Form.Controls.Add($titleHDD)

$HDD = New-Object System.Windows.Forms.label
$HDD.Location = New-Object System.Drawing.Point(65,230)
$HDD.width = 150
$HDD.height = 80
$HDD.Text = Disk
$HDD.Font= 'Microsoft Sans Serif,8'
$HDD.TextAlign = 'topLeft'
$HDD.AutoSize = $false
$Form.Controls.Add($HDD)


$titleHDDhealth = New-Object System.Windows.Forms.Label
$titleHDDhealth.Location = New-Object System.Drawing.Point(0,290)
$titleHDDhealth.AutoSize = $false
$titleHDDhealth.width = 65
$titleHDDhealth.height = 15
$titleHDDhealth.Font= 'Arial Black,8'
$titleHDDhealth.ForeColor='black'
$titleHDDhealth.BackColor = 'darkcyan'
$titleHDDhealth.Text = "Santé"
$titleHDDhealth.TextAlign = 'Middleleft'
$Form.Controls.Add($titleHDDhealth)


$HDDhealth = New-Object System.Windows.Forms.label
$HDDhealth.Location = New-Object System.Drawing.Point(0,310)
$HDDhealth.width = 215
$HDDhealth.height = 280
$HDDhealth.Text = hdss
$HDDhealth.Font= 'Microsoft Sans Serif,8'
$HDDhealth.ForeColor='darkblue'
$HDDhealth.TextAlign = 'topleft'
$HDDhealth.AutoSize = $false
$Form.Controls.Add($HDDhealth)


#Ram
function ram
{
$getRamCapacity1 = Get-CimInstance win32_physicalmemory | Select-Object -Expand Capacity -first 1
$getRamCapacitygb1 = ($getRamCapacity1 / 1gb)
$getRamCapacity2 = Get-CimInstance win32_physicalmemory | Select-Object -Expand Capacity -skip 1 -first 1
$getRamCapacitygb2 = ($getRamCapacity2 / 1gb)
$getRamCapacity3 = Get-CimInstance win32_physicalmemory | Select-Object -Expand Capacity -skip 2 -first 1
$getRamCapacitygb3 = ($getRamCapacity3 / 1gb)
$getRamCapacity4 = Get-CimInstance win32_physicalmemory | Select-Object -Expand Capacity -skip 3 -first 1
$getRamCapacitygb4 = ($getRamCapacity4 / 1gb)
 
    if ($getRamCapacity1)
    {
        #$getRamDeviceLocator = Get-CimInstance win32_physicalmemory | Select-Object -Expand Devicelocator -first 1
        $getRamDeviceLocator = Get-CimInstance win32_physicalmemory | Select-Object -Property @{Name = 'Devicelocator'; Expression = {$_.Devicelocator -replace "Controller",""  -replace "Channel", "" -replace "Dimm", ""}} | select-object -expand Devicelocator -first 1 
        #$getRamManufacturer = Get-CimInstance win32_physicalmemory | Select-Object -Expand Manufacturer -first 1 
        $getRamManufacturer = Get-CimInstance win32_physicalmemory | Select-Object -Property @{Name = 'Manufacturer'; Expression = {$_.Manufacturer -replace "Unknown","N/A" }} | select-object -expand Manufacturer -first 1 
        $getRamClockspeed = Get-CimInstance win32_physicalmemory | Select-Object -Expand Configuredclockspeed -first 1
        $answerram1 = "$getRamDeviceLocator :$getRamManufacturer,$getRamCapacitygb1 GB,$getRamClockspeed mhz"
        "$answerram1`r`n"
    }
    if ($getRamCapacity2)
    {
        $getRamDeviceLocator = Get-CimInstance win32_physicalmemory | Select-Object -Property @{Name = 'Devicelocator'; Expression = {$_.Devicelocator -replace "Controller","" -replace "Channel", "" -replace "Dimm", ""}} | select-object -expand Devicelocator -skip 1 -first 1 
        $getRamManufacturer = Get-CimInstance win32_physicalmemory | Select-Object -Property @{Name = 'Manufacturer'; Expression = {$_.Manufacturer -replace "Unknown","N/A"}} | select-object -expand Manufacturer -skip 1 -first 1 
        $getRamClockspeed = Get-CimInstance win32_physicalmemory | Select-Object -Expand Configuredclockspeed -skip 1 -first 1
        $answerram2 = "$getRamDeviceLocator :$getRamManufacturer,$getRamCapacitygb2 GB,$getRamClockspeed mhz"
        "$answerram2`r`n"
    }
    if ($getRamCapacity3)
    {
        $getRamDeviceLocator = Get-CimInstance win32_physicalmemory | Select-Object -Property @{Name = 'Devicelocator'; Expression = {$_.Devicelocator -replace "Controller","" -replace "Channel", "" -replace "Dimm", ""}} | select-object -expand Devicelocator -skip 2 -first 1 
        $getRamManufacturer = Get-CimInstance win32_physicalmemory | Select-Object -Property @{Name = 'Manufacturer'; Expression = {$_.Manufacturer -replace "Unknown","N/A"}} | select-object -expand Manufacturer -skip 2 -first 1 
        $getRamClockspeed = Get-CimInstance win32_physicalmemory | Select-Object -Expand Configuredclockspeed -skip 2 -first 1
        $answerram3 = "$getRamDeviceLocator :$getRamManufacturer,$getRamCapacitygb3 GB,$getRamClockspeed mhz"
        "$answerram3`r`n"
    }
    if ($getRamCapacity4)
    {
        $getRamDeviceLocator = Get-CimInstance win32_physicalmemory | Select-Object -Property @{Name = 'Devicelocator'; Expression = {$_.Devicelocator -replace "Controller","" -replace "Channel", "" -replace "Dimm", ""}} | select-object -expand Devicelocator -skip 3 -first 1 
        $getRamManufacturer = Get-CimInstance win32_physicalmemory | Select-Object -Property @{Name = 'Manufacturer'; Expression = {$_.Manufacturer -replace "Unknown","N/A"}} | select-object -expand Manufacturer -skip 3 -first 1 
        $getRamClockspeed = Get-CimInstance win32_physicalmemory | Select-Object -Expand Configuredclockspeed -skip 3 -first 1
        $answerram4 = "$getRamDeviceLocator :$getRamManufacturer,$getRamCapacitygb4 GB,$getRamClockspeed mhz"
        "$answerram4`r`n"
    }
}

#espace libre total
$getRamtotalspace = Get-CimInstance Win32_OperatingSystem | Select-Object -Expand totalvisiblememorysize
$getRamtotalspaceGB = [int]($getRamtotalspace / 1mb)
$getRamFreespace = Get-CimInstance Win32_OperatingSystem | Select-Object -Expand FreePhysicalMemory
$getRamFreespaceGB = [int]($getRamFreespace / 1mb)
$percentagefreespaceram = ($getRamFreespaceGB / $getRamtotalspaceGB).tostring("P")


$titleRam = New-Object System.Windows.Forms.Label
$titleRam.Location = New-Object System.Drawing.Point(215,130)
$titleRam.AutoSize = $false
$titleRam.width = 65
$titleRam.height = 15
$titleRam.Font= 'Arial Black,8'
$titleRam.ForeColor='black'
$titleRam.BackColor = 'darkcyan'
$titleRam.Text = "RAM"
$titleRam.TextAlign = 'Middleleft'
$Form.Controls.Add($titleRam)

$Raminfo = New-Object System.Windows.Forms.label
$Raminfo.Location = New-Object System.Drawing.Point(215,150)
$Raminfo.width = 200
$Raminfo.height = 80
$Raminfo.Text = ram
$Raminfo.Font= 'Microsoft Sans Serif,8'
$Raminfo.TextAlign = 'topLeft'
$Raminfo.AutoSize = $false
$Form.Controls.Add($Raminfo)


$titleRamCapacityGB = New-Object System.Windows.Forms.Label
$titleRamCapacityGB.Location = New-Object System.Drawing.Point(215,230)
$titleRamCapacityGB.AutoSize = $false
$titleRamCapacityGB.width = 65
$titleRamCapacityGB.height = 15
$titleRamCapacityGB.Font= 'Arial Black,8'
$titleRamCapacityGB.ForeColor='black'
$titleRamCapacityGB.BackColor = 'darkcyan'
$titleRamCapacityGB.Text = "Cap. Tot."
$titleRamCapacityGB.TextAlign = 'Middleleft'
$Form.Controls.Add($titleRamCapacityGB)

$RamCapacityGB = New-Object System.Windows.Forms.label
$RamCapacityGB.Location = New-Object System.Drawing.Point(280,230)
$RamCapacityGB.width = 150
$RamCapacityGB.height = 15
$RamCapacityGB.Text = "$getRamtotalspaceGB" + "GB " + "(" + "$percentagefreespaceram" + " libre" + ")"
$RamCapacityGB.Font= 'Microsoft Sans Serif,8'
$RamCapacityGB.TextAlign = 'Middleleft'
$RamCapacityGB.AutoSize = $false
$Form.Controls.Add($RamCapacityGB)

#Graphic
$getGPU = Get-CimInstance -Class win32_VideoController | Select-Object -Expand Name
$GPUdriverdate = Get-CimInstance -Class win32_VideoController | Select-Object -Expand Driverdate

$titleGPU = New-Object System.Windows.Forms.Label
$titleGPU.Location = New-Object System.Drawing.Point(215,270)
$titleGPU.AutoSize = $false
$titleGPU.width = 65
$titleGPU.height = 15
$titleGPU.Font= 'Arial Black,8'
$titleGPU.ForeColor='black'
$titleGPU.BackColor = 'darkcyan'
$titleGPU.Text = "Modèle"
$titleGPU.TextAlign = 'Middleleft'
$Form.Controls.Add($titleGPU)

$GPU = New-Object System.Windows.Forms.label
$GPU.Location = New-Object System.Drawing.Point(280,270)
$GPU.width = 150
$GPU.height = 15
$GPU.Text = "$getGPU"
$GPU.Font= 'Microsoft Sans Serif,8'
$GPU.TextAlign = 'middleleft'
$GPU.ForeColor='darkblue'
$GPU.AutoSize = $false
$Form.Controls.Add($GPU)

$titleGPUdriver = New-Object System.Windows.Forms.Label
$titleGPUdriver.Location = New-Object System.Drawing.Point(215,290)
$titleGPUdriver.AutoSize = $false
$titleGPUdriver.width = 65
$titleGPUdriver.height = 15
$titleGPUdriver.Font= 'Arial Black,8'
$titleGPUdriver.ForeColor='black'
$titleGPUdriver.BackColor = 'darkcyan'
$titleGPUdriver.Text = "Pilote"
$titleGPUdriver.TextAlign = 'Middleleft'
$Form.Controls.Add($titleGPUdriver)

$GPUdriver = New-Object System.Windows.Forms.label
$GPUdriver.Location = New-Object System.Drawing.Point(280,290)
$GPUdriver.width = 150
$GPUdriver.height = 15
$GPUdriver.Text = "$GPUdriverdate"
$GPUdriver.Font= 'Microsoft Sans Serif,8'
$GPUdriver.TextAlign = 'MiddleLeft'
$GPUdriver.AutoSize = $false
$Form.Controls.Add($GPUdriver)

#MotherBoard
$getmoboProduct = Get-WmiObject win32_baseboard | Select-Object -Expand Product | Out-string
$getmoboManufacturer = Get-WmiObject win32_baseboard | Select-Object -Expand Manufacturer | Out-string
$getmoboSerial = Get-WmiObject win32_baseboard | Select-Object -Expand SerialNumber | Out-string

$titlegetmoboProduct = New-Object System.Windows.Forms.Label
$titlegetmoboProduct.Location = New-Object System.Drawing.Point(0,150)
$titlegetmoboProduct.AutoSize = $false
$titlegetmoboProduct.width = 65
$titlegetmoboProduct.height = 15
$titlegetmoboProduct.Font= 'Arial Black,8'
$titlegetmoboProduct.ForeColor='black'
$titlegetmoboProduct.BackColor = 'darkcyan'
$titlegetmoboProduct.Text = "Modèle"
$titlegetmoboProduct.TextAlign = 'Middleleft'
$Form.Controls.Add($titlegetmoboProduct)

$MoboProduct = New-Object System.Windows.Forms.label
$MoboProduct.Location = New-Object System.Drawing.Point(65,150)
$MoboProduct.width = 150
$MoboProduct.height = 15
$MoboProduct.Text = "$getMoboProduct"
$MoboProduct.Font= 'Microsoft Sans Serif,8'
$MoboProduct.TextAlign = 'MiddleLeft'
$MoboProduct.AutoSize = $false
$Form.Controls.Add($MoboProduct)

$titlegetmoboManufacturer = New-Object System.Windows.Forms.Label
$titlegetmoboManufacturer.Location = New-Object System.Drawing.Point(0,170)
$titlegetmoboManufacturer.AutoSize = $false
$titlegetmoboManufacturer.width = 65
$titlegetmoboManufacturer.height = 15
$titlegetmoboManufacturer.Font= 'Arial Black,8'
$titlegetmoboManufacturer.ForeColor='black'
$titlegetmoboManufacturer.BackColor = 'darkcyan'
$titlegetmoboManufacturer.Text = "Marque"
$titlegetmoboManufacturer.TextAlign = 'Middleleft'
$Form.Controls.Add($titlegetmoboManufacturer)

$MoboManufacturer = New-Object System.Windows.Forms.label
$MoboManufacturer.Location = New-Object System.Drawing.Point(65,170)
$MoboManufacturer.width = 150
$MoboManufacturer.height = 15
$MoboManufacturer.Text = "$getMoboManufacturer"
$MoboManufacturer.Font= 'Microsoft Sans Serif,8'
$MoboManufacturer.TextAlign = 'MiddleLeft'
$MoboManufacturer.AutoSize = $false
$Form.Controls.Add($MoboManufacturer)


$titlegetmoboSerial = New-Object System.Windows.Forms.Label
$titlegetmoboSerial.Location = New-Object System.Drawing.Point(0,190)
$titlegetmoboSerial.AutoSize = $false
$titlegetmoboSerial.width = 65
$titlegetmoboSerial.height = 15
$titlegetmoboSerial.Font= 'Arial Black,8'
$titlegetmoboSerial.ForeColor='black'
$titlegetmoboSerial.BackColor = 'darkcyan'
$titlegetmoboSerial.Text = "# série"
$titlegetmoboSerial.TextAlign = 'Middleleft'
$Form.Controls.Add($titlegetmoboSerial)

$MoboSerial = New-Object System.Windows.Forms.label
$MoboSerial.Location = New-Object System.Drawing.Point(65,190)
$MoboSerial.width = 150
$MoboSerial.height = 15
$MoboSerial.Text = "$getmoboSerial"
$MoboSerial.Font= 'Microsoft Sans Serif,8'
$MoboSerial.TextAlign = 'MiddleLeft'
$MoboSerial.AutoSize = $false
$Form.Controls.Add($MoboSerial)

#Battery
Function Batteryexist
{
$wmiBattery = @(Get-WmiObject Win32_Battery).count
    IF ($wmiBattery -ne 0)
	{
	    battery
	}
    ELSE	
	{
	    "Pas de batterie"
	}
}


function battery
{
            powercfg /batteryreport /xml /output batteryreport.xml | out-null
            $battery = [xml](Get-Content batteryreport.xml)
            $full = $battery.BatteryReport.Batteries.Battery.FullChargeCapacity
            $design = $battery.BatteryReport.Batteries.Battery.DesignCapacity
            $a = $full/$design * 100
            " Capacité maximal initiale : $design mWh`r`n"
            "Capacité maximal acutel: $full mWh`r`n"           
            "Santé: $a %"             
}

            
$titleBattery = New-Object System.Windows.Forms.Label
$titleBattery.Location = New-Object System.Drawing.Point(215,330)
$titleBattery.AutoSize = $false
$titleBattery.width = 65
$titleBattery.height = 15
$titleBattery.Font= 'Arial Black,8'
$titleBattery.ForeColor='black'
$titleBattery.BackColor = 'darkcyan'
$titleBattery.Text = "Santé"
$titleBattery.TextAlign = 'Middleleft'
$Form.Controls.Add($titleBattery)

$Battery = New-Object System.Windows.Forms.label
$Battery.Location = New-Object System.Drawing.Point(215,350)
$Battery.width = 250
$Battery.height = 80
$Battery.Text = Batteryexist
$Battery.Font= 'Microsoft Sans Serif,8'
$Battery.TextAlign = 'topLeft'
$Battery.AutoSize = $true
$Form.Controls.Add($Battery)


#quitter
$quit = New-Object System.Windows.Forms.Button
$quit.Location = New-Object System.Drawing.Point(275,425)
$quit.Width = '75'
$quit.Height = '50'
$quit.ForeColor= 'darkred'
$quit.BackColor = 'black'
$quit.Text = "Quitter"
$quit.Font= 'Microsoft Sans Serif,12'
$quit.FlatStyle = 'Flat'
$quit.FlatAppearance.BorderSize = 3
$quit.FlatAppearance.BorderColor = 'black'
$quit.FlatAppearance.MouseDownBackColor = 'Darkcyan'
$quit.FlatAppearance.MouseOverBackColor = 'darkred'
$quit.Add_MouseEnter({$quit.ForeColor = 'black'})
$quit.Add_MouseLeave({$quit.ForeColor = 'darkred'})
$quit.Enabled = $true
$quit.Add_Click({
$Form.Close()
Stop-Process -name sysinfoz -Force
})
$Form.Controls.Add($quit)

$sync.titleCPULoad = $titleCPULoad
$sync.CPULoad = $CPULoad

$Form.Controls.AddRange(@($sync.titleCPULoad, $sync.CPULoad))
$Form.ShowDialog() | out-null