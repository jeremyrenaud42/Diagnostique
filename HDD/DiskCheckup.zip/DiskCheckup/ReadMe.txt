PassMark (R) Software's DiskCheckup
Copyright (C) 2006-2021 PassMark Software
All Rights Reserved
http://www.passmark.com

Overview
========
PassMark DiskCheckup� allows the user to monitor the SMART attributes of a particular hard disk drive. SMART (Self Monitoring Analysis & Reporting Technology) is an interface between a computer's BIOS (basic input/output system) and the computer hard disk. It is a feature of the Enhanced Integrated Drive Electronics (EIDE) technology that controls access to the hard drive. If S.M.A.R.T is enabled when a computer is set up, the BIOS can receive analytical information from the hard drive and determine whether to send the user a warning message about possible future failure of the hard drive.


Status
======
Free for personal use. Company license is US$19 per license.

Contact PassMark� software, asking about our attractive rates for Multi-user and site licenses.

sales@passmark.com



Installation
============
Run the DiskCheckup.exe installation file.


UnInstallation
==============
Run the uninstaller from the directory that the program was installed or
from the DiskCheckup's Start menu uninstaller.  
    

Requirements
======================
Platforms:  Windows XP-SP3, Server 2003, Vista, Server 2008, Windows 7, Windows Server 2012, Windows 8, Windows 10 (requires administrative privileges)
16 MB RAM, 2 MB of disk space


Version History
===============
Here is a summary of all changes that have been made in each version of DiskCheckup (v2.0 build 1002 onwards).

Revision            Author      Date
v3.5 (1001)         SL          11 May 2021
------------------------------------------------------------------- 
1. Fixed a bug where on some SATA drives the 'Temperature Warning Level Exceeded' was displaying 
   even though temperatures were actually below what was set in the configuration menu
2. Diskcheckup translated into Chinese (Traditional) and French

Revision            Author      Date
v3.5 (1000)         JH          16 Apr 2021
------------------------------------------------------------------- 
1. Built with SysInfo DLL v2.1 build 1006
   - Add support for more types of M2 NVMe solid state drives

Revision            Author      Date
v3.4 (1003)         KM          3 Feb 2017
------------------------------------------------------------------- 
1. Added support for retrieving NVMe SMART info in Win10
2. Added check for 'SanDisk' in the model name and if detected, do not perform byte order reversal
3. Added check for 'THNS' (Toshiba) string in model name and if present, do not perform byte order reversal
4. 'ECC size' and 'Buffer size' are now reported as 'N/A' if the value is 0
5. Fixed low disk space warning incorrectly appearing for large drives (ie. > 1TB)

Revision            Author      Date
v3.4 (1002)         KM          15 Jun 2016
------------------------------------------------------------------- 
1. Added SATA signaling speed support to the device info. Fixed ambiguity between SATA signalling speed support and SATA transport compliance.
2. Fixed bug with exported report showing strange characters in the 'Interface' field
3. Fixed exported report not showing correct SMART attributes info for NVMe disks
4. Fixed attribute ID not being stored for NVMe SMART TEC data

Revision            Author      Date
v3.4 (1001)         KM          10 Mar 2016
------------------------------------------------------------------- 
1. Fixed bug with strange characters appearing on the TEC notification message box
2. Fixed bug with TEC notification incorrectly being triggered when temperature attribute is below the threshold


Revision            Author      Date
v3.4 (1000)         KM          8 Mar 2016
------------------------------------------------------------------- 
1. Added device info + SMART support for PCIe M.2 NVMe Samsung and Intel drives


Revision            Author      Date
v3.3 (1000)         KM          3 Feb 2015
------------------------------------------------------------------- 
1. Updated list of SMART attributes according to the specific drive model.
   The set of SMART attributes to display is determined by performing a 
   regular expression comparison on the drive model.
2. SMART Info tab now contains an 'Info' icon which displays a 
   description of the SMART attribute when moused over. Each attribute
   may also display an up or down icon to indicate whether a higher 
   or lower raw value is better.
3. SMART History tab now displays the raw value history.
4. A new 'Status' attribute is displayed in the Device Info tab which indicates
   that a drive is "OK" unless:
      a) < 10% disk space is available in any of the disk's volumes,
      b) Disk temperature is higher than the threshold, or
      c) 1 or more SMART value(s) have exceeded a threshold
5. Device Info tab now displays the disk's real-time activity. The refresh
   interval can be configured in the Configuration window.
6. Fixed issue with dates being truncated in the exported report. Also removed
   errors appearing in the reports when no SMART history is available.


Revision            Author      Date
v3.2 (1000)         RN          15 Nov 2013
------------------------------------------------------------------- 
1. Diskcheckup translated into Chinese, Spanish, and German. Users can
   edit the localization.txt file in the program folder to translate to
   other languages. Users are encouraged to submit their localization.txt
   file for any languages that are not yet available to be possibly included
   in future releases.
2. Maximum number of devices increased to 64.


Revision            Author      Date
v3.1 (1007)         KM          9 May 2013
------------------------------------------------------------------- 
1. Fixed crash when retrieving the maximum native LBA for some USB drives
2. Disk Self Test is now disabled if not supported
3. Fixed incorrect error message displayed when attempting to execute self test


Revision            Author      Date
v3.1 (1006)         KM          17 Apr 2013
------------------------------------------------------------------- 
1. Added 'Hidden Areas - HPA/DCO' tab for detecting/setting HPA/DCO areas


Revision            Author      Date
v3.1 (1005)         KM          10 Aug 2012
------------------------------------------------------------------- 
1. Fixed crash (in XP) when exporting a drive's SMART history due to an uninitialized library
2. Added an exception handler to generate a dump on crash


Revision            Author      Date
v3.1 (1004)         KM          22 May 2012
------------------------------------------------------------------- 
1. Fixed crash (in XP) when displaying a drive's Device Info due to an uninitialized library


Revision            Author      Date
v3.1 (1003)         KM          16 May 2012
------------------------------------------------------------------- 
1. SMART attributes specific to common SSD drives are now displayed
2. Devices are now grouped into "SMART-enabled Devices" or "Other Devices"


Revision            Author      Date
v3.1 (1002)         KM          27 Apr 2012
------------------------------------------------------------------- 
1. DiskCheckup now displays all detected drives, not just SMART-enabled drives


Revision            Author      Date
v3.1 (1001)         KM          15 Sep 2011
------------------------------------------------------------------- 
1. Removed pop-up dialog when refreshing disks


Revision            Author      Date
v3.1 (1000)         KM          24 Jun 2011
------------------------------------------------------------------- 
1. Added support for executing disk self tests (if implemented by the drive)
2. Drive information can now be refreshed by pressing 'F5' or clicking on the refresh button.
   Clicking on the drive icon will no longer refresh the drive information.
3. Minor UI fixes


Revision            Author      Date
v3.0 (1009)         KM          01 Jun 2011
------------------------------------------------------------------- 
1. DiskCheckup now attempts to issue SMART commands regardless if SMART enable failed (SysInfo DLL fix)


Revision            Author      Date
v3.0 (1008)         KM          26 May 2011
------------------------------------------------------------------- 
1. Fixed issue with drives reporting the same capacity (SysInfo DLL fix)
2. Improved error handling for sending e-mail notification


Revision            Author      Date
v3.0 (1007)         RN          4 May 2011
------------------------------------------------------------------- 
1. Built with SysInfo DLL v1.0 build 1012
2. Fixed program not responding issue with some email servers that stop responding when sending email


Revision            Author      Date
v3.0 (1006)         KM          25 Jan 2011
------------------------------------------------------------------- 
1. Fixed memory leak when no SMART history available
2. Increased the number of physical disks supported


Revision            Author      Date
v3.0 (1005)         KM          4 Jan 2011
------------------------------------------------------------------- 
1. Fixed raw values displayed as hexadecimal in DiskCheckup report files


Revision            Author      Date
v3.0 (1004)         KM          2 Nov 2010
------------------------------------------------------------------- 
1. Fixed bug causing crash during startup
2. Minor fixes


Revision            Author      Date
v3.0 (1003)         KM          19 Aug 2010
------------------------------------------------------------------- 
1. Added SMTP authentication support for e-mail notifications.
2. Added '-d' command line argument for debug mode (Debug mode is off by default).
3. Added '-m' command line argument to start DiskCheckup minimized to system tray.


Revision            Author      Date
v3.0 (1002)         KM          6 Aug 2010
------------------------------------------------------------------- 
1. Fixed issue with some drive types not being detected (but previously detected by DiskCheckup v2.1).


Revision            Author      Date
v3.0 (1001)         KM          2 Aug 2010
-------------------------------------------------------------------
1. Fixed message prompt issue when there is a media card reader with no media inserted.
2. Fixed issue with e-mail alert not being sent when the disk temperature is equal to the temperature warning level.

Revision            Author      Date
v3.0 (1000)         KM          6 July 2010
-------------------------------------------------------------------
1. Built with SysInfo DLL v1.0 build 1000
   - Includes support for USB/firewire hard drives
   - Updated list of SMART attributes
2. Updated the attributes in the Device Info tab to reflect changes in the SysInfoDll_Smart_GetDeviceInfo API
3. Fixed issue with SMART history not reflecting the current drive's SMART attributes


Revision            Author      Date
v2.0 (1004)         SK          20 Feb 2009
-------------------------------------------------------------------
1.  Built with SmartDisk DLL v1.0 (build 1012)
    - Fixed bug whereby Win9x users will be prompted with:
        "There were errors trying to gather the SMART info.
        You have no access rights to gather drive information."
    - Found a possible bug whereby when calling DeviceIOControl to gather SMART
    data, the bDriveHeadReg of the IDEREGS structure is not assigned correctly.
    - Added GETVERSIONOUTPARAMS to DEVICEINFO in SmartDisk.h.  This struct contains
    the device capabilities and IDE device map.

        
Revision            Author      Date
v2.0 (1003)         SK          04 Dec 2006
-------------------------------------------------------------------
1.  Fixed bug whereby the path of DiskCheckup.cfg is not proper (it was using "DiskCheckup.cfg"
    in the current working directory).  Path is now concatenated with current module directory.
    This should fix the symptom whereby when DiskCheckup is launched from the command line,
    it does not remember the last configuration that it was saved.

2.  Built with MAP file.

3.  Added -c command line parameter to allow user to choose configuration file to load.
    Example: DiskCheckup -c "C:\Documents and Settings\user\My Documents\test.cfg"

4.  Fixed reported crash when trying to get hardisks details.

5.  Built with SmartDisk DLL v1.0 (build 1011)
    - DLL was also calling WMI class, which is not being used at all.
    - WMI module commented out to prevent name pollution.
    - DebugLogWriteLine is changed to DllDebugWriteLine.
    - Fixed behaviour whereby if a virtual drive is present (a drive
    created with the Windows tool "subst", whereby a folder is
    associated with a drive letter), DiskCheckup prompts that
    user has no access rights and exits.  It should now display all
    other valid drives and skip virtual drives.
    
6.  Help files built with H&M 4.2 (rids security warning when viewing help
    from IE).

Revision            Author      Date
v2.0 (1002)         SK          25 Oct 2006
-------------------------------------------------------------------
1.  v2.0 (build 1001) was still reporting duplicate drives.  This version should fix this issue.

2.  On Vista, instead of just saying "You have no access rights...", we now print info on
how they can run it as an administrator.

3.  When user changed temperature warning level, Smart Info is not updating its status correctly
(amber: warning, black: ok)

4.  Temperature warning should warn when temperature is equal or more than warning level.
This is now corrected.

5.  Built with SmartDisk DLL v1.0 (build 1010)
    - fixed issue where checking of TEC for temperature is not correct (becuase RAW value
    of temperature as obtained from some drive has high order garbage).
    - Should handdle running under Windows 98/Me better.  Function not supported under Windows 98/Me
    should now return STATUS_ERR_FUNCTION_NOT_SUPPORTED from SmartDisk DLL.  DiskCheckup will then
    treat such info as "N.A." and display all other available info.
    
6.  Changed to browser-based online HTML help files from compiled HTML help files (.chm files
    does not like hashes '#' in its path and also will not open over network drives due
    to XP's security features).
    
Documentation
=============
All the documentation is included in the online help file.
It can be accessed from the help button.


Support
=======
For technical support, questions, suggestions, please check the help file for 
our email address or visit our web page at http://www.passmark.com/support/index.htm


Ordering / Registration
=======================
All the details are in the help file documentation
or you can visit our sales information page
http://www.passmark.com/sales


Specific Disclaimer on Failure Predictions
==========================================
DiskCheckup utilizes statistical analysis to predict possible failure
dates of hard disk drives. Because there are no �certainties� in statistical analysis,
PassMark� Software Pty Ltd disclaims all liability for any and all costs incurred by either:

1)  The hard disk drive failing before the predicted failure date
    estimated by the application, or
2)  The hard disk drive continuing to function beyond the predicted
    failure date estimated by the application.

In either situation, PassMark� disclaims liability for any losses due to loss or damage to
data. PassMark� further disclaims any liability for costs incurred in anticipation of a disk
drive failure that does not eventuate (e.g. replacement hard disk drives, transfer time, downtime, etc).

This disclaimer is in addition to the Disclaimer of Warranty and Limitation of Liability
mentioned elsewhere in this EULA and on our web site.



Enjoy..
The PassMark Development team